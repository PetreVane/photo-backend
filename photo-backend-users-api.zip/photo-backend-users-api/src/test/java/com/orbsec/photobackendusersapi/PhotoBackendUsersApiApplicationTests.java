package com.orbsec.photobackendusersapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoBackendUsersApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
