package com.orbsec.photobackendapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoBackendApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
